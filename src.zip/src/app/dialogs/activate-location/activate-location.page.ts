import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activate-location',
  templateUrl: './activate-location.page.html',
  styleUrls: ['./activate-location.page.scss'],
})
export class ActivateLocationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
