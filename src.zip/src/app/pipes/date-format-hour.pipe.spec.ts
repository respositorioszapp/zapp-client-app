import { DateFormatHourPipe } from './date-format-hour.pipe';

describe('DateFormatHourPipe', () => {
  it('create an instance', () => {
    const pipe = new DateFormatHourPipe();
    expect(pipe).toBeTruthy();
  });
});
