export interface Taxes {
    rate_base: string,
    km_base: string,
    km_unit_value: string,
    neighboring_base: string,
    tax_declared_value: string
}