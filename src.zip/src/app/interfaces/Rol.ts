export interface Rol {
    id: number
    name: string
    special: string
}