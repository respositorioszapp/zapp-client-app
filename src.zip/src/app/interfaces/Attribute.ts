export interface Attribute {
    id?: number,
    name?: string,
    img?: string,
    value?: number,
    parameter_id?: number,
}