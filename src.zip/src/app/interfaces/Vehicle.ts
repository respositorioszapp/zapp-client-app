export interface Vehicle {
    brand: string
    color: string
    id: number
    model: string
    plate: string
    soat: string
    technomechanical: string
    year : number
    transport_type_id: string
    user_id: number
}