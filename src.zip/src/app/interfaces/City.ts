export interface City{
    id?: number,
    name?: string,
    latitude?: string,
    longitude?: string,
    state_id?: number
    status?: string,
    name_state?: string
}