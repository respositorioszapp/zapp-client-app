export interface Companies {
    business_name: string
    city: string
    city_id: number
    id: number
    nit: number
    payment_address: string
    status: string
}