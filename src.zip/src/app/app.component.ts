import { Component, QueryList, ViewChildren } from '@angular/core';

import { IonRouterOutlet, Platform } from '@ionic/angular';
import { SplashScreen } from '@awesome-cordova-plugins/splash-screen/ngx';
import { Capacitor } from '@capacitor/core';
import { ConnectionStatus } from '@capacitor/network';

//const {StatusBar} = Plugins
import { StatusBar } from '@awesome-cordova-plugins/status-bar/ngx';

import { FcmService } from './services/fcm.service';
import { Router } from '@angular/router';
import { UiService } from './services/ui.service';
import { Location } from '@angular/common';
import ModalOptions from './interfaces/ModalOptions';
import { CloseShopPage } from './dialogs/close-shop/close-shop.page';
import { App } from '@capacitor/app';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {
  networkStatus: ConnectionStatus
  @ViewChildren(IonRouterOutlet) routerOutlets: QueryList<IonRouterOutlet>;

  lastTimeBackPress = 0;
  timePeriodToExit = 2000;
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    
    private fcm :FcmService,
    private location: Location,
    private router: Router,
    private ui: UiService,
    private statusBar:StatusBar
  ) {
    this.backButtonEvent()
    this.initializeApp();
  }

  initializeApp() {
    
    this.platform.ready().then(() => {
    
      this.statusBar.overlaysWebView(false);
      
//      this.statusBar.backgroundColorByHexString("transparent");
      // this.statusBar.styleDefault();
      this.splashScreen.hide();
      this.fcm.initPush();
    });
  }

  backButtonEvent() {
    //This subscription is for the native back button works correctly
    App.addListener('backButton', ({ canGoBack }) => {
      if (!this.router.url.includes('tabs/home')) {
        // await this.router.navigate(['/']);
        window.history.back();
      } else if (this.router.url.includes('tabs/home')) {
        if (new Date().getTime() - this.lastTimeBackPress >= this.timePeriodToExit) {
          this.lastTimeBackPress = new Date().getTime();
          this.presentAlertConfirm();
        } else {
          App.exitApp();
        }
      }
    });
  }

  async presentAlertConfirm() {
    const obj: ModalOptions = {
      // image: 'assets/imgs/location-animation.gif',
      message:"Está seguro de cerrar la aplicación?",
      color_message: "#000000",
      color_title: "#000000",
      affirmativeText:"Cerrar",
      negativeText:"Cancelar",
      modalWithButtons:true,
      affirmativeMethod:() => {
        App.exitApp();
      }
    }
    const modal = await this.ui.presentModal(CloseShopPage, obj, ["modal-xxs","box-shadow-modal"])
  }
}


