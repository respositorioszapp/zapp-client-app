import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dummy-create-order',
  templateUrl: './dummy-create-order.page.html',
  styleUrls: ['./dummy-create-order.page.scss'],
})
export class DummyCreateOrderPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
